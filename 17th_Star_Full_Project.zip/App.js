import React from 'react';
import { View, StatusBar } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import RitualSchedulerCalendar from './components/RitualSchedulerCalendar';
import RitualArchiveGallery from './components/RitualArchiveGallery';
import SacredCompanionOrb from './components/SacredCompanionOrb';
import StarSettingsToggle from './components/StarSettingsToggle';
import StarMessageBundle from './components/StarMessageBundle';

export default function App() {
  return (
    <SafeAreaProvider>
      <StatusBar barStyle="light-content" />
      <View style={{ flex: 1, backgroundColor: '#0f0f1b' }}>
        <RitualSchedulerCalendar />
        <RitualArchiveGallery />
        <StarSettingsToggle />
        <StarMessageBundle />
        <SacredCompanionOrb />
      </View>
    </SafeAreaProvider>
  );
}
