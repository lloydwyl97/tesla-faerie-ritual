# 17th Star App

To run:
1. `npm install`
2. `npx expo login`
3. `npx eas build --platform android`
4. Or run locally: `npx expo start`